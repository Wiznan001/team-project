# **1.Project Title:星座生日查询小程序**
    这是一个基于现代Web技术开发的交互式应用程序，旨在为用户提供个性化的生日、星座和运势查询服务。程序拥有美观的用户界面和丰富的功能，包括生日倒计时、星座查询、年龄计算、今日运势查看以及报告导出等功能。

![alt text]({62EEF049-A1CB-4111-9F8B-71734A27711C}-1.png)

# **2.Getting Started:**
## 2.1.Prerequisites:
* 现代浏览器: <label style="color:#00ffff">Chrome 70+、Firefox 65+、Safari 12+、Edge 79+</label>

* 屏幕分辨率: 支持各种移动设备和桌面设备

* 网络连接: 仅用于加载***Font Awesome***图标库(可选)
## 2.2.Installing:
1. 登陆网址：https://github.com/Wiznan001/team-project.git

2. 下载：Birthday-Frontend.html，并保存为<u>.html</u>文件

3. 双击文件使用浏览器打开即可使用
![alt text]({3BC51F55-17AD-488a-BD56-B66C3DCFB5F3}-1.png)
# **3.Running the tests:**
## 3.1.日期选择测试
* 选择不同日期验证界面响应

* 测试边界日期(如闰年2月29日)



## 3.2.功能模块测试
```javascript
// 测试代码
describe('年龄计算功能', () => {
  it('应该正确计算周岁和虚岁', () => {
    const result = calculateChineseAge(new Date(2000, 5, 15));
    expect(result.actualAge).toBe(23);
    expect(result.nominalAge).toBe(24);
  });
});
```
## 3.3.界面响应测试
* 测试不同屏幕尺寸的适配性
  
* 验证交互动画流畅性

# **4.Usage:**
## 4.1.基本功能
* 生日倒计时

* 输入出生日期后查看距离下一个生日的天数

* 显示已出生天数统计

## 4.2.星座查询
* 自动根据生日确定星

* 显示星座图标和特性描述

## 4.3.年龄计算
* 周岁: 精确计算实际年龄

* 虚岁: 中国传统年龄计算方式

* 出生天数统计

## 4.4.今日运势
* 每日随机生成运势报告

* 包含幸运指数、颜色和数字

## 4.5.报告导出
* 生成完整的生日运势报告

* 支持导出功能

<center><img src="{433616F4-17D7-4c0b-A12F-E9C8759EC0BE}-1.png" alt="示例" width="60%" /></center>

## 注：API接口
```javascript
// 生日天数计算API
POST /api/days
Body: { "birthdate": "2000-06-15" }
Response: { "days": 125, "status": "success" }

// 星座查询API
POST /api/zodiac
Body: { "birthdate": "2000-06-15" }
Response: { "zodiac": "双子座", "status": "success" }

// 运势查询API
GET /api/luck
Response: { "luck_score": 85, "lucky_color": "紫色", ... }
```
# **5.Contributing:**
| 角色            |    姓名      |         职责 |GitHub邮箱 |
| --------------- | ----------   | --------------- |--- |
|项目负责人、前端开发者兼测试工程师 |郑成果  |  项目管理与协调、界面设计与实现、质量保证与测试|u202312024@hust.edu.cn |
|基本功能开发  |陈宜樊 |开发生日倒计时查询功能及出生天数查询 |2531667684@qq.com |
|星座查询功能开发   |王玺博    | 开发星座查询功能 |2420869328@qq.com |
|运势查询功能开发   |张浩    | 开发运势查询功能并导出至文件 |m13097019852@163.com |
|年龄计算功能开发   |黄成浩    | 开发周岁虚岁查询功能 |2605999674@qq.com |
<center><img src="1756092352212.png" alt="示例" width="60%" /></center>
我们欢迎任何形式的贡献！请阅读我们的贡献指南并提交Pull Request。


# **6.Versioning:**
* ## v1.0.0 (2025-8-22)

✅ 基础功能实现
✅ 响应式界面设计

✅ 年龄计算功能(周岁+虚岁)
✅ 运势生成系统

* ## v0.5.0 (2025-8-21)
✅ 初始项目结构
✅ 基本界面框架

✅ 日期选择功能



# **7.License:MIT 许可证**
> MIT License

    Copyright (c) 2023 [团队名称或作者姓名]

    特此免费授予任何获得本软件及相关文档文件（以下简称"软件"）副本的人士，无限制地处理本软件的权限，包括但不限于使用、复制、修改、合并、发布、分发、再许可和/或销售本软件的副本，并允许向其提供软件的人员这样做，但须符合以下条件：上述版权声明和本许可声明应包含在软件的所有副本或重要部分中。

    本软件"按原样"提供，不附带任何明示或暗示的担保，包括但不限于对适销性、特定用途适用性和非侵权性的担保。在任何情况下，作者或版权持有人均不对因软件或软件的使用或其他交易而产生的任何索赔、损害赔偿或其他责任负责，无论是在合同诉讼、侵权行为还是其他方面。

# **8.Acknowledgments:**
* ## Font Awesome 提供精美的图标资源
* ## Google Fonts 提供优质字体服务
* ## CSS Gradient 提供美丽的渐变背景
* ## 所有测试用户和贡献者的宝贵反馈

<center><img src="OIP-C.webp" alt="示例" width="80%" /></center>

# <label style="color:#00bfff">***特别感谢所有使用本程序的用户，你们的反馈是我们改进的动力！***</label>